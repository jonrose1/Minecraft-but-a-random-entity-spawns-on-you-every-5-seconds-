package me.jrooairle.minecraftbut;

import org.bukkit.plugin.java.JavaPlugin;

import me.jrooairle.minecraftbut.commands.SpawnCommand;

public class Main extends JavaPlugin {

	@Override
	public void onEnable() {
		
		new SpawnCommand(this);
	}
	
}
