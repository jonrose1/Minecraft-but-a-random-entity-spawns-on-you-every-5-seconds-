package me.jrooairle.minecraftbut.commands;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import me.jrooairle.minecraftbut.Main;

public class SpawnCommand implements CommandExecutor {
	
 boolean done = false;
private Main plugin;
int times = 0;
	public SpawnCommand(Main plugin) {
		this.plugin = plugin;
		plugin.getCommand("randomentity").setExecutor(this);
	}
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		Player p = (Player) sender;
		
		if (done) {
			done = false;
			p.sendMessage("Plugin Disabled!");
			return false;
		} else {
			p.sendMessage("Plugin Enabled!");
			done = true;
		}
		
			
		Bukkit.getScheduler().scheduleSyncRepeatingTask(plugin, new Runnable() {
		    @Override
		    public void run() {
		    	//String[] entities = {"AREA_EFFECT_CLOUD", "ARMOR_STAND", "ARROW", "BAT", "BEE", "BLAZE", "BOAT", "CAT", "CAVE_SPIDER", "CHICKEN", "COD", "COW", "CREEPER", "DOLPHIN", "DONKEY", "DRAGON_FIREBALL", "DROWNED", "EGG", "ELDER_GUARDIAN", "ENDER_CRYSTAL", "ENDER_DRAGON", "ENDER_PEARL", "ENDER_SIGNAL", "ENDERMAN", "ENDERMITE", "EVOKER", "EVOKER_FANGS", "EXPERIENCE_ORB", "FALLING_BLOCK", "FIREBALL", "FIREWORK", "FOX", "GHAST", "GIANT", "GUARDIAN", "HOGLIN", "HORSE", "HUSK", "ILLUSIONER", "IRON_GOLEM", "LIGHTNING", "LLAMA", "LLAMA_SPIT", "MAGMA_CUBE", "MINECART", "MINECART_CHEST", "MINECART_COMMAND", "MINECART_FURNACE", "MINECART_HOPPER", "MINECART_MOB_SPAWNER", "MINECART_TNT", "MULE", "MUSHROOM_COW", "OCELOT", "PANDA", "PARROT", "PHANTOM", "PIG", "PIGLIN", "PIGLIN_BRUTE", "PILLAGER", "PLAYER", "POLAR_BEAR", "PRIMED_TNT", "PUFFERFISH", "RABBIT", "RAVAGER", "SALMON", "SHEEP", "SHULKER", "SHULKER_BULLET", "SILVERFISH", "SKELETON", "SKELETON_HORSE", "SLIME", "SMALL_FIREBALL", "SNOWBALL", "SNOWMAN", "SPIDER", "SQUID	", "STRAY	", "STRIDER", "THROWN_EXP_BOTTLE", "TRADER_LLAMA", "TRIDENT", "TROPICAL_FISH", "TURTLE", "VEX", "VILLAGER", "VINDICATOR", "WANDERING_TRADER", "WITCH", "WITHER", "WITHER_SKELETON	", "WITHER_SKULL", "WOLF", "ZOGLIN", "ZOMBIE", "ZOMBIE_HORSE", "ZOMBIE_VILLAGER", "ZOMBIFIED_PIGLIN"};
    			int c = (int)(Math.random() * (91 - 1 + 1) + 1);
    			c--;
    			Location loc = p.getLocation();
    			World w = p.getWorld();
    		//	String temp = entities[c];
    			
    			if (done) {
    			if (c == 0) {
    				w.spawnEntity(loc, EntityType.AREA_EFFECT_CLOUD);
    			} else if (c == 1) {
    				w.spawnEntity(loc, EntityType.ARMOR_STAND);
    			} else if (c == 2) {
    				w.spawnEntity(loc, EntityType.ARROW);
    			} else if (c == 3) {
    				w.spawnEntity(loc, EntityType.BAT);
    			} else if (c == 4) {
    				w.spawnEntity(loc, EntityType.BEE);
    			} else if (c == 5) {
    				w.spawnEntity(loc, EntityType.BLAZE);
    			} else if (c == 6) {
    				w.spawnEntity(loc, EntityType.BOAT);
    			} else if (c == 7) {
    				w.spawnEntity(loc, EntityType.CAT);
    			} else if (c == 8) {
    				w.spawnEntity(loc, EntityType.CAVE_SPIDER);
    			} else if (c == 9) {
    				w.spawnEntity(loc, EntityType.CHICKEN);
    			} else if (c == 10) {
    				w.spawnEntity(loc, EntityType.COD);
    			} else if (c == 11) {
    				w.spawnEntity(loc, EntityType.COW);
    			} else if (c == 12) {
    				w.spawnEntity(loc, EntityType.CREEPER);
    			} else if (c == 13) {
    				w.spawnEntity(loc, EntityType.DOLPHIN);
    			} else if (c == 14) {
    				w.spawnEntity(loc, EntityType.DONKEY);
    			} else if (c == 15) {
    				w.spawnEntity(loc, EntityType.DRAGON_FIREBALL);
    			} else if (c == 16) {
    				w.spawnEntity(loc, EntityType.DROWNED);
    			} else if (c == 17) {
    				w.spawnEntity(loc, EntityType.EGG);
    			} else if (c == 18) {
    				w.spawnEntity(loc, EntityType.ELDER_GUARDIAN);
    			} else if (c == 19) {
    				w.spawnEntity(loc, EntityType.ENDER_CRYSTAL);
    			} else if (c == 20) {
    				w.spawnEntity(loc, EntityType.ENDERMAN);
    			} else if (c == 21) {
    				w.spawnEntity(loc, EntityType.ENDERMITE);
    			} else if (c == 22) {
    				w.spawnEntity(loc, EntityType.EVOKER);
    			} else if (c == 23) {
    				w.spawnEntity(loc, EntityType.EVOKER_FANGS);
    			} else if (c == 24) {
    				w.spawnEntity(loc, EntityType.EXPERIENCE_ORB);
    			} else if (c == 25) {
    				w.spawnEntity(loc, EntityType.FIREBALL);
    			} else if (c == 26) {
    				w.spawnEntity(loc, EntityType.FIREWORK);
    			} else if (c == 27) {
    				w.spawnEntity(loc, EntityType.FOX);
    			} else if (c == 28) {
    				w.spawnEntity(loc, EntityType.GHAST);
    			} else if (c == 29) {
    				w.spawnEntity(loc, EntityType.GIANT);
    			} else if (c == 30) {
    				w.spawnEntity(loc, EntityType.GUARDIAN);
    			} else if (c == 31) {
    				w.spawnEntity(loc, EntityType.HOGLIN);
    			} else if (c == 32) {
    				w.spawnEntity(loc, EntityType.HORSE);
    			} else if (c == 33) {
    				w.spawnEntity(loc, EntityType.HUSK);
    			} else if (c == 34) {
    				w.spawnEntity(loc, EntityType.ILLUSIONER);
    			} else if (c == 35) {
    				w.spawnEntity(loc, EntityType.IRON_GOLEM);
    			} else if (c == 36) {
    				w.spawnEntity(loc, EntityType.LIGHTNING);
    			} else if (c == 37) {
    				w.spawnEntity(loc, EntityType.LLAMA);
    			} else if (c == 38) {
    				w.spawnEntity(loc, EntityType.MAGMA_CUBE);
    			} else if (c == 39) {
    				w.spawnEntity(loc, EntityType.MINECART);
    			} else if (c == 40) {
    				w.spawnEntity(loc, EntityType.MINECART_CHEST);
    			} else if (c == 41) {
    				w.spawnEntity(loc, EntityType.MINECART_COMMAND);
    			} else if (c == 42) {
    				w.spawnEntity(loc, EntityType.MINECART_FURNACE);
    			} else if (c == 43) {
    				w.spawnEntity(loc, EntityType.MINECART_HOPPER);
    			} else if (c == 44) {
    				w.spawnEntity(loc, EntityType.MINECART_MOB_SPAWNER);
    			} else if (c == 45) {
    				w.spawnEntity(loc, EntityType.MINECART_TNT);
    			} else if (c == 46) {
    				w.spawnEntity(loc, EntityType.MULE);
    			} else if (c == 47) {
    				w.spawnEntity(loc, EntityType.MUSHROOM_COW);
    			} else if (c == 48) {
    				w.spawnEntity(loc, EntityType.OCELOT);
    			} else if (c == 49) {
    				w.spawnEntity(loc, EntityType.PANDA);
    			} else if (c == 50) {
    				w.spawnEntity(loc, EntityType.PARROT);
    			} else if (c == 51) {
    				w.spawnEntity(loc, EntityType.PHANTOM);
    			} else if (c == 52) {
    				w.spawnEntity(loc, EntityType.PIG);
    			} else if (c == 53) {
    				w.spawnEntity(loc, EntityType.PIGLIN);
    			} else if (c == 54) {
    				w.spawnEntity(loc, EntityType.PILLAGER);
    			} else if (c == 55) {
    				w.spawnEntity(loc, EntityType.POLAR_BEAR);
    			} else if (c == 56) {
    				w.spawnEntity(loc, EntityType.PRIMED_TNT);
    			} else if (c == 57) {
    				w.spawnEntity(loc, EntityType.PUFFERFISH);
    			} else if (c == 58) {
    				w.spawnEntity(loc, EntityType.RABBIT);
    			} else if (c == 59) {
    				w.spawnEntity(loc, EntityType.RAVAGER);
    			} else if (c == 60) {
    				w.spawnEntity(loc, EntityType.SALMON);
    			} else if (c == 61) {
    				w.spawnEntity(loc, EntityType.SHEEP);
    			} else if (c == 62) {
    				w.spawnEntity(loc, EntityType.SHULKER_BULLET);
    			} else if (c == 63) {
    				w.spawnEntity(loc, EntityType.SILVERFISH);
    			} else if (c == 64) {
    				w.spawnEntity(loc, EntityType.SKELETON);
    			} else if (c == 65) {
    				w.spawnEntity(loc, EntityType.SKELETON_HORSE);
    			} else if (c == 66) {
    				w.spawnEntity(loc, EntityType.SLIME);
    			} else if (c == 67) {
    				w.spawnEntity(loc, EntityType.SMALL_FIREBALL);
    			} else if (c == 68) {
    				w.spawnEntity(loc, EntityType.SNOWMAN);
    			} else if (c == 69) {
    				w.spawnEntity(loc, EntityType.SPIDER);
    			} else if (c == 70) {
    				w.spawnEntity(loc, EntityType.SQUID);
    			} else if (c == 71) {
    				w.spawnEntity(loc, EntityType.STRAY);
    			} else if (c == 72) {
    				w.spawnEntity(loc, EntityType.STRIDER);
    			} else if (c == 73) {
    				w.spawnEntity(loc, EntityType.THROWN_EXP_BOTTLE);
    			} else if (c == 74) {
    				w.spawnEntity(loc, EntityType.TRADER_LLAMA);
    			} else if (c == 75) {
    				w.spawnEntity(loc, EntityType.TROPICAL_FISH);
    			} else if (c == 76) {
    				w.spawnEntity(loc, EntityType.TURTLE);
    			} else if (c == 77) {
    				w.spawnEntity(loc, EntityType.VEX);
    			} else if (c == 78) {
    				w.spawnEntity(loc, EntityType.VILLAGER);
    			} else if (c == 79) {
    				w.spawnEntity(loc, EntityType.VINDICATOR);
    			} else if (c == 80) {
    				w.spawnEntity(loc, EntityType.WANDERING_TRADER);
    			} else if (c == 81) {
    				w.spawnEntity(loc, EntityType.WITCH);
    			} else if (c == 82) {
    				w.spawnEntity(loc, EntityType.WITHER);
    			} else if (c == 83) {
    				w.spawnEntity(loc, EntityType.WITHER_SKELETON);
    			} else if (c == 84) {
    				w.spawnEntity(loc, EntityType.WITHER_SKULL);
    			} else if (c == 85) {
    				w.spawnEntity(loc, EntityType.WOLF);
    			} else if (c == 86) {
    				w.spawnEntity(loc, EntityType.ZOGLIN);
    			} else if (c == 87) {
    				w.spawnEntity(loc, EntityType.ZOMBIE);
    			} else if (c == 88) {
    				w.spawnEntity(loc, EntityType.ZOMBIE_HORSE);
    			} else if (c == 89) {
    				w.spawnEntity(loc, EntityType.ZOMBIE_VILLAGER);
    			} else if (c == 90) {
    				w.spawnEntity(loc, EntityType.ZOMBIFIED_PIGLIN);
    			} else {
    				p.kickPlayer("Error");
    			}
    				

}
		    }
		}, 0L, 100L); 
                	
                	
		return false;
}
}
